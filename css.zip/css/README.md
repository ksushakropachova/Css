# Задание на самостоятельное выполнение по теме CSS-селекторов

A Pen created on CodePen.io. Original URL: [https://codepen.io/bcherepakha/pen/vxRMyN](https://codepen.io/bcherepakha/pen/vxRMyN).

